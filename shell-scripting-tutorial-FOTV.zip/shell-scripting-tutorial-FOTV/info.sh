#!/bin/bash
#Purpose: eval command Evaluating twice
#Version:1.0
#Created Date: Wed Jun 13 22:09:59 IST 2018
#Modified Date:
#WebSite: https://arkit.co.in
#Author: Ankam Ravi Kumar
# START #

echo "Hi you there"
echo "what is your name? (Type your name here and press Enter)"
read NM
echo "Hi  $NM Good Morning"
echo "your currently logged in as $USER"
echo "your present working directory is `pwd`"

# END #
