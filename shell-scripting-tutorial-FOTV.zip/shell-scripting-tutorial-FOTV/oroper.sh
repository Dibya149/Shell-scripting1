#!/bin/bash
#Website: https://arkit.co.in
if ! [[ $1 -lt 20 || $2 -ge 30 ]]; then
echo "Statement is True"
else
echo "Statment is False"
fi
